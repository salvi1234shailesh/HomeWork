<?php
  $conn = mysqli_connect("localhost","root","","demo");
  if($conn == True && isset($_POST['logout'])){
    session_start();
    session_destroy($_SESSION['name']);
    echo "<h1>Log Out successfull</h1>";
  }
 ?>
